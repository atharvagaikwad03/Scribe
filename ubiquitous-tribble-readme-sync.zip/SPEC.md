# CI-integrated auto-README plugin

## Goal

A pipeline plugin that runs on every build/push and keeps `README.md`
synchronized with the actual state of the codebase — not written once and
left stale, but regenerated/patched on every merge.

## Trigger

CI step (GitHub Action / pre-push hook / build pipeline stage) fires after
a successful build, before/after the push completes.

## Scope of what it should capture

- Project structure (entry points, folder layout, detected framework/language)
- Public API surface (exported functions, CLI commands, endpoints) —
  diffed against the last known surface, not re-derived from scratch each time
- Install/run/build commands — pulled from actual config (`package.json`
  scripts, `Makefile`, `Dockerfile`, `pyproject.toml`) rather than guessed
- Dependency list and version
- Recent meaningful changes (from commit messages / diff summarization)
  folded into a changelog-style section

## Key design constraint that makes this non-trivial (and is the actual interesting problem)

Existing tools (readme-ai, various GH Actions) mostly do a one-shot full
regeneration from an LLM prompt — which clobbers manually-written prose,
badges, custom sections, and drifts in tone every run. The harder, more
useful version is surgical:

1. Parse the existing README into sections (via markdown AST, e.g. headers
   as anchors).
2. Mark which sections are "generated" (owned by the tool, e.g. wrapped in
   `<!-- autogen:start:api -->...<!-- autogen:end:api -->`) vs. human-owned
   free text.
3. Diff the codebase since the last generation (via git diff on the last
   commit the tool ran against) and only regenerate the generated sections
   that are affected — e.g. a new exported function updates the API section
   but doesn't touch the "Why this project exists" prose someone wrote by
   hand.
4. Fail closed: if the tool can't confidently map a change to a section, it
   should flag a PR comment ("README may be stale here") instead of
   guessing and corrupting content.

## Failure modes to design against

- **Infinite loop**: the README update itself is a commit, which could
  re-trigger the pipeline — needs a guard (skip-ci tag, or check "did only
  README.md change").
- **Merge conflicts**: two branches both trigger README regen — needs to
  run post-merge on the target branch, not per-branch, or rebase-safe.
- **Monorepos**: one README vs. per-package READMEs — scope needs to be
  configurable.

## What's genuinely novel here vs. what already exists

The section-ownership + incremental-diff-based regeneration (rather than
full LLM rewrite each time) is the differentiator — that's the part that
mainstream tools don't do well yet.

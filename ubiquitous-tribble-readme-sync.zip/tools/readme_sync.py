#!/usr/bin/env python3
"""Surgical README generator: only touches autogen:* sections.

Usage:
    python3 tools/readme_sync.py generate <path-to-project-root>
    python3 tools/readme_sync.py check <path-to-project-root>

`generate` rewrites only the content between matching
`<!-- autogen:start:NAME -->` / `<!-- autogen:end:NAME -->` marker pairs
found in <root>/README.md. Everything outside those markers -- including
markers that don't exist yet -- is left untouched (fail closed).

`check` prints a report of which sections would change without writing
anything, and exits non-zero if any generated section is stale. This is
what a CI "PR check" step would call.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

MARKER_RE = re.compile(
    r"<!--\s*autogen:start:(?P<name>[\w-]+)\s*-->.*?<!--\s*autogen:end:(?P=name)\s*-->",
    re.DOTALL,
)

IGNORE_DIRS = {".git", "node_modules", "__pycache__", ".readme-sync", "dist", "build", ".venv"}


# ---------------------------------------------------------------------------
# Detectors -- each one reads real project files, never guesses.
# ---------------------------------------------------------------------------

def detect_structure(root: Path) -> str:
    lang = []
    if (root / "package.json").exists():
        lang.append("Node.js")
    if (root / "pyproject.toml").exists() or (root / "requirements.txt").exists():
        lang.append("Python")
    if (root / "Cargo.toml").exists():
        lang.append("Rust")
    if (root / "go.mod").exists():
        lang.append("Go")
    lang_line = ", ".join(lang) if lang else "unknown"

    entry_points = []
    pkg = _read_json(root / "package.json")
    if pkg and pkg.get("main"):
        entry_points.append(pkg["main"])
    if (root / "src" / "index.js").exists():
        entry_points.append("src/index.js")
    if (root / "main.py").exists():
        entry_points.append("main.py")

    tree_lines = _tree(root, max_depth=2)

    lines = [f"**Detected stack:** {lang_line}"]
    if entry_points:
        lines.append(f"**Entry point(s):** {', '.join(sorted(set(entry_points)))}")
    lines.append("")
    lines.append("```")
    lines.extend(tree_lines)
    lines.append("```")
    return "\n".join(lines)


def detect_commands(root: Path) -> str:
    rows = []
    pkg = _read_json(root / "package.json")
    if pkg and pkg.get("scripts"):
        for name, cmd in pkg["scripts"].items():
            rows.append((f"npm run {name}", cmd))

    makefile = root / "Makefile"
    if makefile.exists():
        for line in makefile.read_text().splitlines():
            m = re.match(r"^([a-zA-Z0-9_-]+):", line)
            if m and not line.startswith("\t") and m.group(1) not in (".PHONY",):
                rows.append((f"make {m.group(1)}", f"Makefile target `{m.group(1)}`"))

    if (root / "Dockerfile").exists():
        rows.append(("docker build .", "builds the image from Dockerfile"))

    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        text = pyproject.read_text()
        if "poetry" in text:
            rows.append(("poetry install", "installs dependencies (Poetry detected)"))

    if not rows:
        return "_No install/run/build commands detected in package.json, Makefile, Dockerfile, or pyproject.toml._"

    lines = ["| Command | Source |", "| --- | --- |"]
    for cmd, source in rows:
        lines.append(f"| `{cmd}` | {source} |")
    return "\n".join(lines)


def detect_dependencies(root: Path) -> str:
    rows = []
    pkg = _read_json(root / "package.json")
    if pkg:
        for name, ver in (pkg.get("dependencies") or {}).items():
            rows.append((name, ver, "runtime"))
        for name, ver in (pkg.get("devDependencies") or {}).items():
            rows.append((name, ver, "dev"))

    req = root / "requirements.txt"
    if req.exists():
        for line in req.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                rows.append((line, "", "runtime"))

    if not rows:
        return "_No dependency manifest found._"

    lines = ["| Package | Version | Type |", "| --- | --- | --- |"]
    for name, ver, kind in rows:
        lines.append(f"| `{name}` | {ver or '-'} | {kind} |")
    return "\n".join(lines)


CONVENTIONAL_PREFIXES = {
    "feat": "Features",
    "fix": "Fixes",
    "docs": "Docs",
    "refactor": "Refactors",
    "chore": "Chores",
}


def detect_changelog(root: Path, limit: int = 8) -> str:
    try:
        out = subprocess.run(
            ["git", "log", f"-{limit}", "--pretty=format:%h %s", "--", str(root)],
            cwd=root if (root / ".git").exists() else _git_root(root),
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
    except Exception:
        return "_No git history available._"

    if not out:
        return "_No commits recorded for this path yet._"

    groups: dict[str, list[str]] = {}
    for line in out.splitlines():
        sha, _, subject = line.partition(" ")
        m = re.match(r"^(\w+)(\(.+\))?:\s*(.*)$", subject)
        if m and m.group(1) in CONVENTIONAL_PREFIXES:
            bucket = CONVENTIONAL_PREFIXES[m.group(1)]
            groups.setdefault(bucket, []).append(f"{m.group(3)} (`{sha}`)")
        else:
            groups.setdefault("Other", []).append(f"{subject} (`{sha}`)")

    lines = []
    for bucket in ["Features", "Fixes", "Docs", "Refactors", "Chores", "Other"]:
        if bucket in groups:
            lines.append(f"**{bucket}**")
            for item in groups[bucket]:
                lines.append(f"- {item}")
            lines.append("")
    return "\n".join(lines).strip()


SECTION_GENERATORS = {
    "structure": detect_structure,
    "commands": detect_commands,
    "dependencies": detect_dependencies,
    "changelog": detect_changelog,
}


# ---------------------------------------------------------------------------
# Core patch logic
# ---------------------------------------------------------------------------

def patch_readme(root: Path, write: bool) -> tuple[str, list[str], list[str]]:
    readme_path = root / "README.md"
    text = readme_path.read_text()

    found = set(m.group("name") for m in MARKER_RE.finditer(text))
    changed = []

    def _replace(m: re.Match) -> str:
        name = m.group("name")
        generator = SECTION_GENERATORS.get(name)
        if generator is None:
            return m.group(0)  # unknown marker name: leave untouched, fail closed
        new_inner = generator(root)
        old_inner = _inner_text(m.group(0))
        block = f"<!-- autogen:start:{name} -->\n{new_inner}\n<!-- autogen:end:{name} -->"
        if new_inner.strip() != old_inner.strip():
            changed.append(name)
        return block

    new_text = MARKER_RE.sub(_replace, text)

    unmapped = [n for n in found if n not in SECTION_GENERATORS]

    if write and changed:
        readme_path.write_text(new_text)

    return new_text, changed, unmapped


def _inner_text(block: str) -> str:
    m = re.match(r"<!--\s*autogen:start:[\w-]+\s*-->\n?(.*?)\n?<!--\s*autogen:end:", block, re.DOTALL)
    return m.group(1) if m else ""


def _tree(root: Path, max_depth: int, prefix: str = "", depth: int = 0) -> list[str]:
    if depth > max_depth:
        return []
    lines = []
    try:
        entries = sorted(
            [p for p in root.iterdir() if p.name not in IGNORE_DIRS and not p.name.startswith(".")],
            key=lambda p: (p.is_file(), p.name),
        )
    except FileNotFoundError:
        return []
    for p in entries:
        lines.append(f"{prefix}{p.name}{'/' if p.is_dir() else ''}")
        if p.is_dir():
            lines.extend(_tree(p, max_depth, prefix + "  ", depth + 1))
    return lines


def _read_json(path: Path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def _git_root(start: Path) -> Path:
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"], cwd=start, capture_output=True, text=True, check=True
        ).stdout.strip()
        return Path(out)
    except Exception:
        return start


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[0] not in {"generate", "check"}:
        print(__doc__)
        return 2

    mode, root_arg = argv[0], argv[1]
    root = Path(root_arg).resolve()

    if not (root / "README.md").exists():
        print(f"No README.md found at {root}", file=sys.stderr)
        return 2

    write = mode == "generate"
    new_text, changed, unmapped = patch_readme(root, write=write)

    if unmapped:
        print(f"::warning:: README may be stale here — unrecognized autogen sections: {', '.join(unmapped)}")

    if changed:
        print(f"Sections updated: {', '.join(changed)}")
    else:
        print("No generated sections changed.")

    if mode == "check":
        return 1 if changed else 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

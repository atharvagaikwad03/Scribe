const express = require("express");

function createServer(options = {}) {
  const app = express();
  app.get("/health", (req, res) => res.json({ ok: true }));
  return app;
}

function formatUser(user) {
  return `${user.firstName} ${user.lastName}`;
}

module.exports = { createServer, formatUser };

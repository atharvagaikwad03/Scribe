# sample-app

## Why this project exists

We built this because our old user-formatting logic was scattered across
three services and nobody trusted it. This is the single source of truth
now — hand-written section, the tool will never touch this paragraph.

<!-- autogen:start:structure -->
**Detected stack:** Node.js
**Entry point(s):** src/index.js

```
src/
  index.js
Makefile
README.md
package.json
```
<!-- autogen:end:structure -->

<!-- autogen:start:commands -->
| Command | Source |
| --- | --- |
| `npm run build` | node build.js |
| `npm run start` | node src/index.js |
| `npm run test` | node --test test/ |
| `make build` | Makefile target `build` |
| `make run` | Makefile target `run` |
| `make test` | Makefile target `test` |
| `make docker` | Makefile target `docker` |
<!-- autogen:end:commands -->

<!-- autogen:start:dependencies -->
| Package | Version | Type |
| --- | --- | --- |
| `express` | ^4.19.2 | runtime |
| `zod` | ^3.23.8 | runtime |
| `eslint` | ^9.5.0 | dev |
<!-- autogen:end:dependencies -->

## Contributing

Open a PR. Be nice. (Another hand-written section — never touched.)

<!-- autogen:start:changelog -->
**Other**
- Add readme-sync prototype and sample-app demo fixture (`78b9465`)
<!-- autogen:end:changelog -->
